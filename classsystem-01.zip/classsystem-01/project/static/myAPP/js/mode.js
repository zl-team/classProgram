/**
 * 获取模块
 */
function getDataMode(){
	$.ajax({
		type : "get",
		// url : "http://192.168.1.8:8848/classprogram/data/modedata.json",
		url : '/Ajaxclass/',
		dataType : "json",
		async : false,
		success : function(data){
			for(n in data){
				var _data = data[n]
				for(i in _data){
					var id = _data[i][0];
					var name = _data[i][1];
					var url = _data[i][2];
					var iconbd = _data[i][3];
				
					var _li = "<li class='layui-nav-item'>";
						_li +=	"<a class='site-demo-active' data-type='tabAdd' data-url=\""+url+"\" data-id=\""+id+"\" data-title=\""+name+"\" href='javasricpt:void(0);'><i class='layui-icon "+iconbd+"'></i>&nbsp;"+name+"</a>";
						_li +="</li>";
					$('.mk').append(_li);
				}
			}	
		}
		
	});
	
}






