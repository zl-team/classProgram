from django.shortcuts import render

# Create your views here.

from django.http import HttpRequest,HttpResponse

from .models import Nav,Courselist

from django.http import JsonResponse

from json import dumps

from django.core import serializers

def nav(request):
    types = Courselist.objects.all()
    dict = []
    for type in types:
        dic = {}
        dic['cname'] = type.cname
        dic['cid'] = type.cid
        dic['ccredit'] = type.ccredit
        dic['czkz'] = type.czkz
        dic['ccategory'] = type.ccategory
        dic['ctime'] = type.ctime
        dic['cstate'] = type.cstate
        dic['codd'] = type.codd
        dic['cpay'] = type.cpay
        dic['coperation'] = type.coperation
        dict.append(dic)
    return JsonResponse(dict, safe=False)
    # 错误示例，dic放到了外面导致每次循环覆盖了上一次的dic
    # cour=Courselist.objects.all()
    # dic={}
    # lis=[]
    # for i in cour:
    #     dic['cname']=i.cname
    #     print(dic)       
    #     lis.append(dic)
    # return JsonResponse(lis, safe=False)



def Class1(request):
    return render(request,'myAPP/class.html')

def Index(request):
    return render(request,'myAPP/index.html')



def Ajaxclass(request):
    cla=Nav.objects.all()
    lis=[]
    for i in cla:
        lis.append([i.nid,i.nname,i.nurl,i.nicon])
    return JsonResponse({'data':lis})

def Bm(request):
    return render(request,'myAPP/src/bm.html')

def Bk(request):
    return render(request,'myAPP/src/bk.html')

def Cx(request):
    return render(request,'myAPP/src/cx.html')

def Jf(request):
    return render(request,'myAPP/src/jf.html')

def Bd(request):
    return render(request,'myAPP/src/bd.html')

def Bmtable(request):
    types = Courselist.objects.all()
    resultdict = {}
    dict = []
    for type in types:
        dic = {}
        dic['cname'] = type.cname
        dic['cid'] = type.cid
        dic['ccredit'] = type.ccredit
        dic['czkz'] = type.czkz
        dic['ccategory'] = type.ccategory
        dic['ctime'] = type.ctime
        dic['cstate'] = type.cstate
        dic['codd'] = type.codd
        dic['cpay'] = type.cpay
        dic['coperation'] = type.coperation
        dict.append(dic)
    resultdict['code'] = 0
    resultdict['msg'] = ""
    resultdict['count'] =len(dict)
    resultdict['data'] = dict
    return JsonResponse(resultdict, safe=False)

def Kcmc(request):
    types = Courselist.objects.all()
    dict = []
    for type in types:
        dic = {}
        dic['cname'] = type.cname
        dic['cid'] = type.cid
        dic['ccredit'] = type.ccredit
        dic['czkz'] = type.czkz
        dic['ccategory'] = type.ccategory
        dic['ctime'] = type.ctime
        dic['cstate'] = type.cstate
        dic['codd'] = type.codd
        dic['cpay'] = type.cpay
        dic['coperation'] = type.coperation
        dict.append(dic)
    return JsonResponse(dict, safe=False)

def Kcid(request):
    cour = Courselist.objects.all()
    id = request.POST.get("cname")
    print(id)
    dic={}
    for n in cour:
        if id==n.cname:
            dic['ctime']=n.ctime
    # m没有写查询，先直接返回一个数据
    return JsonResponse(dic, safe=False)


        