from django.contrib import admin

# Register your models here.

from .models import Nav,Courselist
# 注册


class NavAdmin(admin.ModelAdmin):
        # 列表页属性
        list_display = ['pk','nid','nname','nurl','nicon','nsDelete','nreatetime','naddtime' ] # 显示字段设置 
        list_filter = ['nname'] # 过滤字段设置
        search_fields = ['nname'] # 搜索字段设置
        list_per_page = 5 # 分页设置
        # 添加，修改页属性
admin.site.register(Nav,NavAdmin)

class CourselistAdmin(admin.ModelAdmin):
     # 列表页属性
    list_display = ['cid','cname','ccredit','czkz','ccategory','ctime','cstate','codd','cpay','coperation'] # 显示字段设置
    list_filter = ['cname'] # 过滤字段设置
    search_fields = ['cname'] # 搜索字段设置
    list_per_page = 5 # 分页设置
#     # 添加，修改页属性
# #     fields = [] # 规定属性的先后顺序
# #     fieldsets = [] # 给属性分组 注意：fields与fieldsets不能同时使用

admin.site.register(Courselist,CourselistAdmin)