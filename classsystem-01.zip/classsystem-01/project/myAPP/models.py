from django.db import models

# Create your models here.

class Nav(models.Model):
    nname = models.CharField(max_length=20)
    nid = models.IntegerField()
    nurl = models.CharField(max_length=20)
    nicon = models.CharField(max_length=20)
    nsDelete = models.BooleanField(default=False)
    nreatetime=models.DateTimeField(auto_now=True)
    naddtime=models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.nname
    class Mate:
        db_table='Nav'
        ordering=['id']

class Courselist(models.Model):
    cname = models.CharField(max_length=20)
    cid = models.IntegerField()
    ccredit = models.IntegerField()
    czkz = models.IntegerField()
    ccategory = models.CharField(max_length=20)
    ctime=models.DateField()
    cstate = models.BooleanField(default=False)
    codd = models.IntegerField()
    cpay = models.BooleanField(default=False)
    coperation = models.BooleanField(default=False)
    def __str__(self):
        return self.cname
    class Mate:
        db_table='Courselist'
        ordering=['id']