from django.urls import path, include
from . import views
app_name='classAPP'
urlpatterns = [
         path('',views.nav),
        #  上面这个路由用于测试
         path('class1/',views.Class1),
         path('class1/index.html',views.Index,name='index'),
         path('Ajaxclass/',views.Ajaxclass),
         path('class1/src/bk.html',views.Bk,name='bk'),
         path('class1/src/jf.html',views.Jf,name='jf'),
         path('class1/src/bm.html',views.Bm,name='bm'),
         path('class1/src/cx.html',views.Cx,name='cx'),
         path('bmtable/',views.Bmtable),
         path('class1/src/bd.html',views.Bd,name='bd'),
         path('kcmc/',views.Kcmc),
         path('kcid/',views.Kcid),
 ]